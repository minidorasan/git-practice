# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '91ea62cadd37dfe33a7e1adb3ad1f0c192753a221dd1d8264e3f33410be3e82267ff32c4d57255dbeb1d5a657a000cbb4a95cca7f7f8a4b290516075deab4d46'